I dont know if this is usefull but here is  tha app's link
 https://play.google.com/store/apps/details?id=com.taleek.app